﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestOnExit : MonoBehaviour {

    void OnTriggerExit()
    {
        Debug.Log("Test");
    }
}
